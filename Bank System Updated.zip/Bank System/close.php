<?php
    // include "controller/validate_customer.php";
    include "header.php";
    // include "customer_navbar.php";
    // include "customer_sidebar.php";
    include "controller/session_timeout.php";
    
    $id = $_SESSION['loggedIn_cust_id'];
    
    $sql0 = "DELETE FROM `customer` WHERE cust_id='".$id."'";
    // $sql0 = "SELECT cust_id FROM customer WHERE cust_id='".$id."'";
    $result = $conn->query($sql0);
    $success = 0;
    if($result->num_rows > 0) {
        if(($conn->query($sql0) === TRUE)) {
            $success = 1;
            header("location: controller/logout.php");
        }else {
            $success = -1;
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/action_style.css">
</head>

<body>
    <div class="flex-container">
        <div class="flex-item">
            <?php
            if ($success == 1) { ?>
                <p id="info"><?php echo "Your account has been closed perminantly!\n"; ?></p>
            <?php } ?>

            <?php
            if ($success == 0) { ?>
                <p id="info"><?php echo "Invalid data entered/Connection error !\n"; ?></p>
            <?php } ?>

            <?php
            if ($success == -1) { ?>
                <p id="info "><?php echo "Can't delete account right now!\n"; ?></p>
            <?php } ?>
        </div>

        <div class="flex-item">
            <a href="./signup.php" class="button">Create another Account</a>
        </div>
    </div>

</body>
</html>
